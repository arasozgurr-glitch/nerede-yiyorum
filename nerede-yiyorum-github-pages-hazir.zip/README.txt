NERede Yiyorum — GitHub Pages sürümü

1) index.html dosyasını GitHub repository'nizin kök dizinine yükleyin.
2) Settings > Pages > Deploy from a branch > main > /(root) seçin.
3) GitHub Pages adresinizi Safari'de açın.
4) Uygulamada sağ üstteki ⚙ simgesinden kısıtlanmış Google Maps API anahtarınızı girin.

API anahtarını GitHub'a koymayın. Google Cloud Console'da Web sitesi/HTTP referrer kısıtlaması ve yalnızca gerekli API kısıtlamalarını uygulayın.
